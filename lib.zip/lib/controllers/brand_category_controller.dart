import 'package:flutter/material.dart';
import 'package:get/get.dart';

class BrandCategoryController extends GetxController {
  final selectedBrand = 'BRITANNIA'.obs;
  final searchController = TextEditingController();

  @override
  void onClose() {
    searchController.dispose();
    super.onClose();
  }

  void selectBrand(String brand) {
    selectedBrand.value = brand;
  }
}
