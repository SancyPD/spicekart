import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:spicekart/controllers/cart_controller.dart';
import '../services/api_service.dart';
import '../model/checkout_preview_response.dart';
import '../model/delivery_slots.dart';
import '../screens/home_screen.dart';
import '../screens/categories_screen.dart';
import '../screens/hot_food_screen.dart';
import '../screens/cart_screen.dart';
import '../screens/usual_items_screen.dart';
import '../screens/order_success_screen.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import '../screens/main_screen.dart';
import 'main_controller.dart';

class CheckoutController extends GetxController {
  final currentIndex = 4.obs;
  final Rx<DeliverySlot?> selectedDeliveryDate = Rx<DeliverySlot?>(null);
  final Rx<Slot?> selectedSlot = Rx<Slot?>(null);
  final selectedDeliverySlot = ''.obs;
  final Rx<int?> selectedTipPercentage = Rx<int?>(null);
  final Rx<String?> selectedPaymentMethod = Rx<String?>(null);

  final couponController = TextEditingController();
  final mobileNumberController = TextEditingController();
  final otpController = TextEditingController();

  final isWalletRedeemed = false.obs;
  final isLoading = true.obs;

  final Rx<CheckoutPreviewResponse?> checkoutData =
      Rx<CheckoutPreviewResponse?>(null);
  final cartItems = <CartItem>[].obs;
  final deliverySlots = <DeliverySlot>[].obs;

  final isOtpSent = false.obs;
  final isPhoneVerified = false.obs;
  final isVerifyingOtp = false.obs;
  final isDeliveryCodeGenerated = false.obs;

  @override
  void onInit() {
    super.onInit();
    // Use microtask to ensure this doesn't run synchronously during a build phase
    Future.microtask(() => fetchCheckoutPreview());

    // Automatically call generateDeliveryCode when the preference changes, if phone is verified
    ever(isDeliveryCodeGenerated, (bool value) {
      if (isPhoneVerified.value) {
        ApiService.generateDeliveryCode(value);
      }
    });
  }

  @override
  void onClose() {
    super.onClose();
  }

  Future<void> fetchCheckoutPreview() async {
    try {
      isLoading.value = true;
      final results = await Future.wait([
        ApiService.checkoutPreview(),
        ApiService.listDeliverySlots(),
      ]);

      final response = results[0] as CheckoutPreviewResponse?;
      final slotsResponse = results[1] as DeliverySlots?;

      checkoutData.value = response;

      print('DEBUG: Checkout Preview Response Status: ${response?.status}');
      if (response != null && response.data.cart != null) {
        print(
          'DEBUG: Cart Items count in response: ${response.data.cart!.cartItems.length}',
        );
        for (var i = 0; i < response.data.cart!.cartItems.length; i++) {
          final item = response.data.cart!.cartItems[i];
          print(
            'DEBUG: Item $i: ${item.product.productName} (ID: ${item.product.id})',
          );
        }
      } else {
        print('DEBUG: response.data.cart is NULL');
      }

      if (response != null &&
          response.data.totalAmountSummary?.tipPercent != null &&
          response.data.totalAmountSummary!.tipPercent > 0) {
        selectedTipPercentage.value = response
            .data
            .totalAmountSummary!
            .tipPercent
            .toInt();
      } else {
        selectedTipPercentage.value = null;
      }

      if (response != null && response.status == 1) {
        cartItems.value = (response.data.cart?.cartItems ?? [])
            .where((item) => item.isSavedForLater == 0)
            .toList();
      } else {
        cartItems.value = [];
      }

      deliverySlots.value = slotsResponse?.data ?? [];

      // Reset selections and match from fresh data
      final cart = response?.data.cart;
      if (cart != null &&
          cart.deliveryDate != null &&
          cart.deliverySlot != null) {
        final existingDate = deliverySlots.firstWhereOrNull(
          (d) =>
              d.deliveryDate.year == cart.deliveryDate!.year &&
              d.deliveryDate.month == cart.deliveryDate!.month &&
              d.deliveryDate.day == cart.deliveryDate!.day,
        );
        if (existingDate != null) {
          selectedDeliveryDate.value = existingDate;
          final existingSlot = existingDate.slots.firstWhereOrNull(
            (s) => s.id == cart.deliverySlot!.id,
          );
          if (existingSlot != null) {
            selectedSlot.value = existingSlot;
          }
        }
      }

      // Fallback to first if nothing selected or matched
      if (selectedDeliveryDate.value == null && deliverySlots.isNotEmpty) {
        selectedDeliveryDate.value = deliverySlots.first;
        if (selectedSlot.value == null &&
            deliverySlots.first.slots.isNotEmpty) {
          selectedSlot.value = deliverySlots.first.slots.first;
        }
      }

      if (response != null && response.data.cart != null) {
        final phone = response.data.cart!.checkoutPhone;
        if (phone != null && phone.trim().isNotEmpty) {
          mobileNumberController.text = phone;
        }

        if (response.data.cart!.checkoutPhoneVerifiedAt != null) {
          isPhoneVerified.value = true;
          // Initial sync of delivery preference if already verified
          ApiService.generateDeliveryCode(isDeliveryCodeGenerated.value);
        }
      }
    } catch (e) {
      print('Error in fetchCheckoutPreview: $e');
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> sendOtp() async {
    final phone = mobileNumberController.text.trim();
    if (phone.isEmpty) {
      Get.snackbar(
        'Error',
        'Please enter a mobile number',
        snackPosition: SnackPosition.BOTTOM,
      );
      return;
    }
    isVerifyingOtp.value = true;
    final result = await ApiService.sendCheckoutPhoneOtp(phone);
    isVerifyingOtp.value = false;

    if (result['success'] == true) {
      isOtpSent.value = true;
      Get.snackbar(
        'Success',
        result['message']?.isNotEmpty == true
            ? result['message']
            : 'OTP sent successfully',
        snackPosition: SnackPosition.BOTTOM,
      );
    } else {
      final errorMessage = result['message']?.isNotEmpty == true
          ? result['message']
          : 'Failed to send OTP';
      Get.snackbar('Error', errorMessage, snackPosition: SnackPosition.BOTTOM);
    }
  }

  Future<void> verifyOtp() async {
    final phone = mobileNumberController.text.trim();
    final otp = otpController.text.trim();
    if (otp.isEmpty) {
      Get.snackbar(
        'Error',
        'Please enter the OTP',
        snackPosition: SnackPosition.BOTTOM,
      );
      return;
    }
    isVerifyingOtp.value = true;
    final success = await ApiService.verifyCheckoutPhoneOtp(phone, otp);
    isVerifyingOtp.value = false;
    if (success) {
      isPhoneVerified.value = true;
      isOtpSent.value = false;
      // Trigger delivery code generation as soon as phone is verified
      ApiService.generateDeliveryCode(isDeliveryCodeGenerated.value);
      Get.snackbar(
        'Success',
        'Phone number verified',
        snackPosition: SnackPosition.BOTTOM,
      );
    } else {
      Get.snackbar('Error', 'Invalid OTP', snackPosition: SnackPosition.BOTTOM);
    }
  }

  void editMobileNumber() {
    isPhoneVerified.value = false;
    isOtpSent.value = false;
    otpController.clear();
  }

  void updateQuantity(int cartItemId, String action) async {
    try {
      isLoading.value = true;
      final success = await ApiService.updateCartItem(
        cartItemId: cartItemId,
        action: action,
      );
      if (success) {
        await fetchCheckoutPreview();
        if (cartItems.isEmpty) {
          if (Get.isRegistered<MainController>()) {
            MainController.to.changeTab(4); // Back to Cart tab
          } else {
            Get.offAll(() => const CartScreen());
          }
        }
      }
    } catch (e) {
      print('Error in updateQuantity: $e');
    } finally {
      isLoading.value = false;
    }
  }

  void deleteCartItem(int cartItemId) async {
    try {
      isLoading.value = true;
      final success = await ApiService.deleteCartItem(cartItemId);
      if (success) {
        await fetchCheckoutPreview();
        if (cartItems.isEmpty) {
          if (Get.isRegistered<MainController>()) {
            MainController.to.changeTab(4); // Back to Cart tab
          } else {
            Get.offAll(() => const CartScreen());
          }
        }
      } else {
        Get.snackbar(
          'Error',
          'Failed to delete item',
          snackPosition: SnackPosition.BOTTOM,
        );
      }
    } catch (e) {
      print('Error in deleteCartItem: $e');
    } finally {
      isLoading.value = false;
    }
  }


  Future<void> applyTip(int percentage) async {
    isLoading.value = true;
    final success = await ApiService.applyTip(percentage);
    if (success) {
      selectedTipPercentage.value = percentage;
      await fetchCheckoutPreview();
    } else {
      Get.snackbar(
        'Error',
        'Failed to apply tip',
        snackPosition: SnackPosition.BOTTOM,
      );
      isLoading.value = false;
    }
  }

  Future<void> processCheckout() async {
    if (selectedPaymentMethod.value == null) {
      Get.snackbar(
        'Error',
        'Please select a payment method first',
        snackPosition: SnackPosition.BOTTOM,
      );
      return;
    }

    final totalAmount =
        checkoutData.value?.data.totalAmountSummary?.total ?? 0.0;
    if (totalAmount <= 0) return;

    isLoading.value = true;

    final checkoutResponse = await ApiService.checkout(
      paymentMethod: selectedPaymentMethod.value!,
    );

    if (checkoutResponse['status'] != 1) {
      isLoading.value = false;
      String errorMessage =
          checkoutResponse['message'] ?? 'Failed to process checkout';
      Get.snackbar('Error', errorMessage, snackPosition: SnackPosition.BOTTOM);
      return;
    }

    if (selectedPaymentMethod.value == 'stripe' ||
        selectedPaymentMethod.value == 'google_pay' ||
        selectedPaymentMethod.value == 'apple_pay') {
      final clientSecret =
          checkoutResponse['data']?['payment_intent_client_secret'];

      final customerId =
      checkoutResponse['data']?['customer_id'];

      final ephemeralKey =
      checkoutResponse['data']?['ephemeral_key'];


      if (clientSecret == null) {
        isLoading.value = false;
        Get.snackbar(
          'Error',
          'Failed to initialize Stripe checkout',
          snackPosition: SnackPosition.BOTTOM,
        );
        return;
      }

      try {
        await Stripe.instance.initPaymentSheet(
          paymentSheetParameters: SetupPaymentSheetParameters(
            paymentIntentClientSecret: clientSecret,
            merchantDisplayName: 'SpiceKart',
            style: ThemeMode.light,
            applePay: selectedPaymentMethod.value == 'apple_pay'
                ? const PaymentSheetApplePay(merchantCountryCode: 'US', )
                : null,
            googlePay: selectedPaymentMethod.value == 'google_pay'
                ? const PaymentSheetGooglePay(
                    merchantCountryCode: 'US',
                    testEnv: true,
                  )
                : null,
            customerId: customerId,
            customerEphemeralKeySecret: ephemeralKey,
          ),
        );
      } catch (e) {
        isLoading.value = false;
        print("Error initializing Payment Sheet: $e");
        return;
      }



      final address = checkoutData.value?.data.cart?.address;
      String formattedAddress = '';
      if (address != null) {
        formattedAddress =
            "${address.addressLine1}${address.addressLine2 != null ? ' ${address.addressLine2}' : ''}, ${address.city}, ${address.state}, ${address.postalCode}";
      }

      try {
        await Stripe.instance.presentPaymentSheet();
        isLoading.value = false;
        // Global cart count update
        CartController.to.updateCartCount();
        Get.offAll(
          () => const OrderSuccessScreen(),
          arguments: formattedAddress,
        );
      } on StripeException catch (e) {
        isLoading.value = false;
        print('Stripe Error: $e');
        Get.snackbar(
          'Error',
          'Payment canceled or failed: ${e.error.localizedMessage}',
          snackPosition: SnackPosition.BOTTOM,
        );
      } catch (e) {
        isLoading.value = false;
        print('Error presenting payment sheet: $e');
      }
    } else {
      isLoading.value = false;

      final address = checkoutData.value?.data.cart?.address;
      String formattedAddress = '';
      if (address != null) {
        formattedAddress =
            "${address.addressLine1}${address.addressLine2 != null ? ' ${address.addressLine2}' : ''}, ${address.city}, ${address.state}, ${address.postalCode}";
      }

      // Global cart count update
      CartController.to.updateCartCount();
      // Handle other payment methods such as net_banking, upi, cod
      Get.offAll(() => const OrderSuccessScreen(), arguments: formattedAddress);
    }
  }

  void onBottomNavTapped(int index) {
    if (Get.isRegistered<MainController>()) {
      MainController.to.changeTab(index);
    } else {
      Get.offAll(() => const MainScreen());
    }
    currentIndex.value = index;
  }

  void toggleWalletRedeemed() {
    isWalletRedeemed.value = !isWalletRedeemed.value;
  }

  Future<void> updateSelectedSlot(DeliverySlot dateDatum, Slot slot) async {
    try {
      selectedDeliveryDate.value = dateDatum;
      selectedSlot.value = slot;

      final date = dateDatum.deliveryDate;
      final dateStr =
          "${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}";

      isLoading.value = true;
      final success = await ApiService.addDeliverySlot(
        deliverySlotId: slot.id,
        deliveryDate: dateStr,
      );

      if (success) {
        // Refresh preview to get updated totals or slot info if needed
        await fetchCheckoutPreview();
      } else {
        Get.snackbar(
          'Error',
          'Failed to update delivery slot',
          snackPosition: SnackPosition.BOTTOM,
        );
      }
    } catch (e) {
      print('Error in updateSelectedSlot: $e');
    } finally {
      isLoading.value = false;
    }
  }
}
