import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:spicekart/screens/checkout_screen.dart';
import 'package:spicekart/screens/user_address_list_screen.dart';
import '../utils/app_theme.dart';
import 'package:spicekart/model/cart_list_response.dart';
import 'package:spicekart/model/saved_items_response.dart' as saved_model;
import 'package:spicekart/services/api_service.dart';
import 'delivery_instructions_screen.dart';
import 'home_screen.dart';
import 'categories_screen.dart';
import 'hot_food_screen.dart';
import '../utils/guest_checker.dart';
import '../model/usuals_response.dart' as usuals;
import 'usual_items_screen.dart';
import 'product_detail_screen.dart';
import '../widgets/custom_bottom_nav_bar.dart';
import '../controllers/cart_controller.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  List<Datum> _cartItems = [];
  List<saved_model.Datum> _savedItems = [];
  List<usuals.Datum> _usualItems = [];
  bool _isLoading = true;
  bool _isProcessingAction = false;
  final Map<int, usuals.Variant> _selectedUsualVariants = {};
  StreamSubscription? _refreshSubscription;

  @override
  void initState() {
    super.initState();
    _fetchCartItems();
    
    // Listen for refresh signal from the bottom navigation bar
    _refreshSubscription = CartController.to.refreshSignal.listen((_) {
      if (mounted) {
        _fetchCartItems(quiet: true); // Use quiet refresh for tab selection
      }
    });
  }

  @override
  void dispose() {
    _refreshSubscription?.cancel();
    super.dispose();
  }


  Future<void> _fetchCartItems({bool quiet = false}) async {
    if (quiet) {
      setState(() => _isProcessingAction = true);
    } else {
      setState(() => _isLoading = true);
    }
    try {
      final cartResponseFuture = ApiService.listCartItems();
      final savedResponseFuture = ApiService.getSavedItemsList();
      final usualsResponseFuture = ApiService.listUsualItems();

      final results = await Future.wait([
        cartResponseFuture,
        savedResponseFuture,
        usualsResponseFuture,
      ]);
      final cartResponse = results[0] as CartListResponse?;
      final savedResponse = results[1] as saved_model.SavedItemsResponse?;
      final usualsResponse = results[2] as usuals.UsualsResponse?;

      setState(() {
        if (cartResponse != null && cartResponse.status == 1) {
          _cartItems = cartResponse.data.where((item) => item.isSavedForLater == 0).toList();
        } else {
          _cartItems = [];
        }

        if (savedResponse != null && savedResponse.status == 1) {
          _savedItems = savedResponse.data;
        } else {
          _savedItems = [];
        }

        if (usualsResponse != null && usualsResponse.status == 1) {
          _usualItems = usualsResponse.data;
        } else {
          _usualItems = [];
        }
        _isLoading = false;
        _isProcessingAction = false;
      });
    } catch (e) {
      debugPrint('Error fetching cart items: $e');
      setState(() {
        _isLoading = false;
        _isProcessingAction = false;
      });
    }
  }
  Future<void> _updateCartItem(int cartItemId, String action) async {
    // Optimistic Update
    final index = _cartItems.indexWhere((item) => item.id == cartItemId);
    if (index == -1) return;

    final originalItem = _cartItems[index];

    if (action == 'decrement' && originalItem.quantity <= 1) {
      ScaffoldMessenger.of(context).hideCurrentSnackBar();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Quantity cannot be less than 1. Use delete instead.'),
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }

    setState(() {
      if (action == 'increment') {
        _cartItems[index] = Datum(
          id: originalItem.id,
          quantity: originalItem.quantity + 1,
          isSavedForLater: originalItem.isSavedForLater,
          product: originalItem.product,
          variant: originalItem.variant,
        );
      } else if (action == 'decrement') {
        _cartItems[index] = Datum(
          id: originalItem.id,
          quantity: originalItem.quantity - 1,
          isSavedForLater: originalItem.isSavedForLater,
          product: originalItem.product,
          variant: originalItem.variant,
        );
      }
    });

    setState(() => _isProcessingAction = true);
    try {
      final success = await ApiService.updateCartItem(
        cartItemId: cartItemId,
        action: action,
      );
      if (success) {
        setState(() => _isProcessingAction = false);
        _fetchCartItems(quiet: true);
      } else {
        // Revert on failure
        setState(() {
          _isProcessingAction = false;
          _cartItems[index] = originalItem;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to update quantity')),
        );
      }
    } catch (e) {
      debugPrint('Error updating cart item: $e');
      setState(() {
        _isProcessingAction = false;
        _cartItems[index] = originalItem;
      });
    }
  }

  Future<void> _deleteItem(int cartId) async {
    final bool? confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Item'),
        content: const Text('Are you sure you want to remove this item from your cart?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('CANCEL'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text(
              'DELETE',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );

    if (confirm == true) {
      final index = _cartItems.indexWhere((item) => item.id == cartId);
      if (index == -1) return;
      final originalItem = _cartItems[index];

      setState(() {
        _isProcessingAction = true;
        _cartItems.removeAt(index);
      });

      try {
        final success = await ApiService.deleteCartItem(cartId);
        if (success) {
          setState(() => _isProcessingAction = false);
          _fetchCartItems(quiet: true);
        } else {
          // Revert on failure
          setState(() {
            _cartItems.insert(index, originalItem);
          });
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Failed to delete item')),
          );
        }
      } catch (e) {
        debugPrint('Error deleting item: $e');
        setState(() {
          _cartItems.insert(index, originalItem);
        });
      }
    }
  }

  Future<void> _toggleSaveForLater(dynamic item, int isSaved) async {
    // Note: 'item' could be from _cartItems (Datum) or _savedItems (saved_model.Datum)
    // Both have .id, .product, .variant, .quantity

    final originalCartItems = List<Datum>.from(_cartItems);
    final originalSavedItems = List<saved_model.Datum>.from(_savedItems);

    setState(() {
      _isProcessingAction = true;
      if (isSaved == 1) {
        // Move from Cart to Saved
        _cartItems.removeWhere((i) => i.id == item.id);
      } else {
        // Move from Saved to Cart
        _savedItems.removeWhere((i) => i.id == item.id);
      }
    });

    try {
      final success = await ApiService.addToCart(
        productId: item.product.id,
        variantId: item.variant.id,
        quantity: item.quantity,
        isSavedForLater: isSaved,
      );
      if (success) {
        setState(() => _isProcessingAction = false);
        _fetchCartItems(quiet: true);
      } else {
        // Revert on failure
        setState(() {
          _isProcessingAction = false;
          _cartItems = originalCartItems;
          _savedItems = originalSavedItems;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to save item')),
        );
      }
    } catch (e) {
      debugPrint('Error toggling save for later: $e');
      setState(() {
        _isProcessingAction = false;
        _cartItems = originalCartItems;
        _savedItems = originalSavedItems;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.white,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.light,
      ),
      child: Scaffold(
      backgroundColor: Colors.grey.shade100,
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              children: [
                // Header Section
                Container(
                  padding: const EdgeInsets.all(16),
                  color: Colors.white,
                  child: Column(
                    children: [
                      // Top row with Back and Checkout button
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          if (Navigator.canPop(context))
                            TextButton(
                              onPressed: () => Navigator.pop(context),
                              style: TextButton.styleFrom(
                                padding: EdgeInsets.zero,
                                minimumSize: Size.zero,
                                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                              ),
                              child: const Text(
                                'Back',
                                style: TextStyle(
                                  color: Color(0xFF4D555C),
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          if (!Navigator.canPop(context))
                          TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom(
                              padding: EdgeInsets.zero,
                              minimumSize: Size.zero,
                              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            ),
                            child: const Text(
                              'Back',
                              style: TextStyle(
                                color: Colors.transparent,
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          ElevatedButton(
                            onPressed: () {
                              if (!GuestChecker.check()) return;
                              if (_cartItems.isEmpty) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('There is no cart items to proceed'),
                                    backgroundColor: Colors.red,
                                  ),
                                );
                                return;
                              }
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const UserAddressListScreen(
                                    isFromCheckout: true,
                                    isInitialFlow: true,
                                  ),
                                ),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.instance.mutedColor,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(
                                horizontal: 20,
                                vertical: 12,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            child: const Text(
                              'PROCEED TO CHECKOUT',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontFamily: 'ITC Avant Garde Gothic Pro',
                                fontWeight: FontWeight.w600,
                                height: 1.30,
                                letterSpacing: 0.48,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),

                    ],
                  ),
                ),
                // Your Cart heading with icon
                Padding(
                  padding: const EdgeInsets.only(left: 16,right: 16,top: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Your Cart',
                        style: TextStyle(
                          color:  Color(0xFF4D555C),
                          fontSize: 18,
                          fontFamily: 'ITC Avant Garde Gothic Pro',
                          fontWeight: FontWeight.w600,
                          height: 1.30,
                          letterSpacing: -0.54,
                        ),
                      ),
                      const Icon(
                        Icons.shopping_cart,
                        size: 28,
                        color: Color(0xFF4D555C),
                      ),
                    ],
                  ),
                ),
                // Cart Items List and Saved Items
                Expanded(
                  child: _isLoading
                      ? const Center(child: CircularProgressIndicator())
                      : SingleChildScrollView(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Cart Items List
                              if (_cartItems.isNotEmpty)
                                ListView.builder(
                                  shrinkWrap: true,
                                  physics: const NeverScrollableScrollPhysics(),
                                  padding: const EdgeInsets.all(16),
                                  itemCount: _cartItems.length,
                                  itemBuilder: (context, index) {
                                    return _buildCartItemCard(_cartItems[index]);
                                  },
                                )
                              else
                                Container(
                                  margin: const EdgeInsets.all(16),
                                  padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 20),
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(12),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withValues(alpha: 0.05),
                                        blurRadius: 10,
                                        offset: const Offset(0, 5),
                                      ),
                                    ],
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Image.asset(
                                        'assets/images/box.png', // Using available box.png as a placeholder for empty cart
                                        width: 120,
                                        height: 120,
                                        color: Colors.grey.shade300,
                                      ),
                                      const SizedBox(height: 20),
                                      const Text(
                                        'Your cart is empty',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: Color(0xFF4D555C),
                                          fontSize: 18,
                                          fontFamily: 'ITC Avant Garde Gothic Pro',
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                      const SizedBox(height: 8),
                                      const Text(
                                        'Looks like you haven\'t added anything yet.',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: Color(0xFF7A8D7C),
                                          fontSize: 14,
                                          fontFamily: 'ITC Avant Garde Gothic Pro',
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              // Don't Forget Your Usuals Section
                              if (_usualItems.isNotEmpty) ...[
                                _buildUsualsSection(),
                                const SizedBox(height: 16),
                              ],
                              // Your Saved Items Section
                              if (_savedItems.isNotEmpty) ...[
                                Container(
                                  margin: const EdgeInsets.symmetric(horizontal: 16),
                                  decoration: ShapeDecoration(
                                    color: Colors.white,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 16,
                                          vertical: 8,
                                        ),
                                        child: const Text(
                                          'Your Saved Items',
                                          style: TextStyle(
                                            color: Color(0xFF4D555C),
                                            fontSize: 16,
                                            fontFamily: 'ITC Avant Garde Gothic Pro',
                                            fontWeight: FontWeight.w600,
                                            height: 1.30,
                                            letterSpacing: -0.48,
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 180,
                                        child: ListView.builder(
                                          scrollDirection: Axis.horizontal,
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 16,
                                          ),
                                          itemCount: _savedItems.length,
                                          itemBuilder: (context, index) {
                                            return _buildSavedItemCard(_savedItems[index]);
                                          },
                                        ),
                                      ),
                                      const SizedBox(height: 8),
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 16),
                              ],
                            ],
                          ),
                        ),
                ),
              ],
            ),
            // Semi-transparent overlay loader
            if (_isProcessingAction)
              Container(
                color: Colors.black.withValues(alpha: 0.1),
                child: const Center(
                  child: CircularProgressIndicator(),
                ),
              ),
          ],
        ),
      ),
    ),
  );
}

  Widget _buildCartItemCard(Datum item) {
    final quantity = item.quantity;
    final product = item.product;
    final variant = item.variant;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Product Image
              Container(
                width: 55,
                height: 55,
                decoration: BoxDecoration(
                  color: AppTheme.instance.backgroundColor,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: CachedNetworkImage(
                    imageUrl: 'https://spicekart1.mockupz.in/storage/products/${product.productImage}',
                    fit: BoxFit.contain,
                    memCacheWidth: 85,
                    fadeInDuration: const Duration(milliseconds: 150),
                    placeholder: (context, url) => Container(
                      color: AppTheme.instance.backgroundColor,
                    ),
                    errorWidget: (context, url, error) =>
                        const Icon(Icons.image_not_supported),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              // Product Details
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Product Name
                    Text(
                      product.productName,
                      style: const TextStyle(
                        color: Color(0xFF4D555C),
                        fontSize: 13,
                        fontFamily: 'ITC Avant Garde Gothic Pro',
                        fontWeight: FontWeight.w600,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),

                    // Weight
                    Text(
                      variant.varientSize,
                      style: const TextStyle(
                        color: Color(0xFF4D555C),
                        fontSize: 12,
                        fontFamily: 'ITC Avant Garde Gothic Pro',
                        fontWeight: FontWeight.w500,
                      ),
                    ),

                    // Unit Price
                    Text(
                      '\$${variant.productPrice}',
                      style: const TextStyle(
                        color: Color(0xFF4D555C),
                        fontSize: 12,
                        fontFamily: 'ITC Avant Garde Gothic Pro',
                        fontWeight: FontWeight.w500,

                      ),
                    ),
                  ],
                ),
              ),
              // Price and Quantity Section
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  // Total Price (Quantity * Price)
                  Text(
                    '\$${(double.parse(variant.productPrice) * quantity).toStringAsFixed(2)}',
                    style: const TextStyle(
                      color: Color(0xFF171717),
                      fontSize: 15,
                      fontFamily: 'ITC Avant Garde Gothic Pro',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 12),
                  // Quantity Selector
                  Container(
                    height: 28,
                    decoration: BoxDecoration(
                      color: AppTheme.instance.secondaryColor,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Minus button
                        IconButton(
                          icon: const Icon(
                            Icons.remove,
                            size: 14,
                            color: Color(0xFFffffff),
                          ),
                          onPressed: () => _updateCartItem(item.id, 'decrement'),
                          padding: const EdgeInsets.all(4),
                          constraints: const BoxConstraints(
                            minWidth: 20,
                            minHeight: 20,
                          ),
                        ),
                        // Quantity display
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          constraints: const BoxConstraints(minWidth: 20),
                          child: Text(
                            '$quantity',
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFFFFFFFF),
                            ),
                          ),
                        ),
                        // Plus button
                        IconButton(
                          icon: const Icon(
                            Icons.add,
                            size: 14,
                            color: Color(0xFFffffff),
                          ),
                          onPressed: () => _updateCartItem(item.id, 'increment'),
                          padding: const EdgeInsets.all(4),
                          constraints: const BoxConstraints(
                            minWidth: 20,
                            minHeight: 20,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 15),
          // Save For Later and Delete buttons
          Row(
            children: [
              GestureDetector(
                onTap: () => _toggleSaveForLater(item, 1),
                child: Container(
                  width: 89,
                  height: 21,
                  decoration: ShapeDecoration(
                    shape: RoundedRectangleBorder(
                      side: const BorderSide(
                        width: 0.50,
                        color: Color(0x918B9D8D),
                      ),
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  child: const Center(
                    child: Text(
                      'Save for later',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Color(0xFF4D555C),
                        fontSize: 10,
                        fontFamily: 'ITC Avant Garde Gothic Pro',
                        fontWeight: FontWeight.w500,
                        height: 1.30,
                        letterSpacing: 0.10,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              GestureDetector(
                onTap: () => _deleteItem(item.id),
                child: Container(
                  width: 50,
                  height: 21,
                  decoration: ShapeDecoration(
                    shape: RoundedRectangleBorder(
                      side: const BorderSide(
                        width: 0.50,
                        color: Color(0x918B9D8D),
                      ),
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  child: const Center(
                    child: Text(
                      'Delete',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Color(0xFF4D555C),
                        fontSize: 10,
                        fontFamily: 'ITC Avant Garde Gothic Pro',
                        fontWeight: FontWeight.w500,
                        height: 1.30,
                        letterSpacing: 0.10,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSavedItemCard(saved_model.Datum item) {
    final product = item.product;
    final variant = item.variant;

    return Container(
      width: 140,
      height: 180,
      margin: const EdgeInsets.only(right: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          // Product Image Container with Badge and Add Button
          SizedBox(
            width: 140,
            height: 110,
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                // Image background container
                Container(
                  width: double.infinity,
                  height: double.infinity,
                  decoration:  ShapeDecoration(
                    color: AppTheme.instance.backgroundColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(2)),
                    ),
                  ),
                  child: Center(
                        child: CachedNetworkImage(
                          imageUrl: 'https://spicekart1.mockupz.in/storage/products/${item.product.productImage}',
                          fit: BoxFit.contain,
                          memCacheWidth: 85,
                          fadeInDuration: const Duration(milliseconds: 150),
                          placeholder: (context, url) => Container(
                            color: AppTheme.instance.backgroundColor,
                          ),
                          errorWidget: (context, url, error) =>
                              const Icon(Icons.image_not_supported),
                        ),
                  ),
                ),
                // Discount badge placeholder
                /*if (item['hasDiscount'] == true)
                  Positioned(
                    top: 8,
                    left: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: const Text(
                        '20% Off',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),*/
                // Move to cart button (corner - extending outside)
                Positioned(
                  bottom: -4,
                  right: -4,
                  child: GestureDetector(
                    onTap: () => _toggleSaveForLater(item, 0),
                    child: Container(
                      width: 24,
                      height: 24,
                      decoration: ShapeDecoration(
                        color: Colors.white,
                        shape: RoundedRectangleBorder(
                          side: const BorderSide(
                            width: 1,
                            color: Color(0xFF4EAEF7),
                          ),
                          borderRadius: BorderRadius.circular(3),
                        ),
                      ),
                      child: const Icon(
                        Icons.add,
                        color: Color(0xFF4EAEF7),
                        size: 16,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 2),
          // Price
          Text(
            '\$${variant.productPrice}',
            style: const TextStyle(
              color: Color(0xFF4D555C),
              fontSize: 12,
              fontFamily: 'ITC Avant Garde Gothic Pro',
              fontWeight: FontWeight.w500,
            ),
          ),
          // Product Name
          Text(
            product.productName,
            style: const TextStyle(
              color: Color(0xFF4D555C),
              fontSize: 11,
              fontFamily: 'ITC Avant Garde Gothic Pro',
              fontWeight: FontWeight.w500,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          // Quantity with dropdown (Size)
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Flexible(
                child: Text(
                  variant.varientSize,
                  style: const TextStyle(
                    color: Color(0xFF4EAEF7),
                    fontSize: 11,
                    fontFamily: 'ITC Avant Garde Gothic Pro',
                    fontWeight: FontWeight.w500,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              const Icon(
                Icons.arrow_drop_down,
                size: 12,
                color: Color(0xFF4EAEF7),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildUsualsSection() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: ShapeDecoration(
        color: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 12,
            ),
            child: Text(
              "Don't Forget Your Usuals",
              style: TextStyle(
                color: Color(0xFF4D555C),
                fontSize: 18,
                fontFamily: 'ITC Avant Garde Gothic Pro',
                fontWeight: FontWeight.w600,
                height: 1.30,
                letterSpacing: -0.54,
              ),
            ),
          ),
          SizedBox(
            height: 230,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _usualItems.length,
              itemBuilder: (context, index) {
                return _buildUsualProductCard(_usualItems[index].product);
              },
            ),
          ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }

  Widget _buildUsualProductCard(usuals.Product product) {
    final variant = _selectedUsualVariants[product.id] ??
        (product.variants.isNotEmpty ? product.variants.first : null);

    final price = variant != null ? '\$${variant.productPrice}' : '\$0.00';
    final weight = variant != null ? variant.varientSize : 'N/A';

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ProductDetailScreen(productId: product.id),
          ),
        );
      },
      child: Container(
        width: 140,
        margin: const EdgeInsets.only(right: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Product Image Container
            SizedBox(
              width: 140,
              height: 110,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Container(
                    width: double.infinity,
                    height: double.infinity,
                    padding: EdgeInsets.symmetric(vertical: 10),
                    decoration: ShapeDecoration(
                      color: AppTheme.instance.backgroundColor,
                      shape: RoundedRectangleBorder(
                        side: BorderSide(
                          width: 1,
                          color: AppTheme.instance.secondaryColor.withValues(alpha: 0.2),
                        ),
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    child: Center(
                      child: product.productImage.isNotEmpty
                          ? CachedNetworkImage(
                              imageUrl: 'https://spicekart1.mockupz.in/storage/products/${product.productImage}',
                              fit: BoxFit.contain,
                              memCacheWidth: 85,
                              fadeInDuration: const Duration(milliseconds: 150),
                              placeholder: (context, url) => Container(
                                color: AppTheme.instance.backgroundColor,
                              ),
                              errorWidget: (context, url, error) =>
                                  const Icon(Icons.image, color: Colors.grey),
                            )
                          : const Icon(Icons.image, color: Colors.grey),
                    ),
                  ),
                  // Add button
                  Positioned(
                    bottom: -4,
                    right: -4,
                    child: GestureDetector(
      onTap: () {
        if (variant == null) return;
        _addUsualToCart(product, variant);
      },
                      child: Container(
                        width: 24,
                        height: 24,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(4),
                          border: Border.all(
                            color: AppTheme.instance.secondaryColor,
                            width: 1,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.1),
                              blurRadius: 2,
                              offset: const Offset(0, 1),
                            ),
                          ],
                        ),
                        child: Icon(
                          Icons.add,
                          color: AppTheme.instance.secondaryColor,
                          size: 16,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            // Price
            Text(
              price,
              style: const TextStyle(
                color: Color(0xFF171717),
                fontSize: 15,
                fontWeight: FontWeight.w600,
                fontFamily: 'ITC Avant Garde Gothic Pro',
              ),
            ),
            const SizedBox(height: 4),
            // Product Name
            Text(
              product.productName,
              style: const TextStyle(
                color: Color(0xFF4D555C),
                fontSize: 13,
                fontWeight: FontWeight.w500,
                fontFamily: 'ITC Avant Garde Gothic Pro',
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 4),
            // Variant dropdown-like row
            GestureDetector(
              onTap: () => _showUsualVariantPicker(product),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    weight,
                    style: TextStyle(
                      color: AppTheme.instance.secondaryColor,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'ITC Avant Garde Gothic Pro',
                    ),
                  ),
                  Icon(
                    Icons.keyboard_arrow_down,
                    size: 16,
                    color: AppTheme.instance.secondaryColor,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _addUsualToCart(usuals.Product product, usuals.Variant variant) async {
    if (!GuestChecker.check(
      action: PendingAction(
        type: PendingActionType.cart,
        productId: product.id,
        variantId: variant.id,
        quantity: 1,
      ),
    )) {
      return;
    }

    setState(() {
      _isProcessingAction = true;
    });

    try {
      final success = await ApiService.addToCart(
        productId: product.id,
        variantId: variant.id,
        quantity: 1,
      );
      if (success) {
        setState(() => _isProcessingAction = false);
        await _fetchCartItems(quiet: true);
        if (!mounted) return;
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            duration: const Duration(seconds: 1),
            behavior: SnackBarBehavior.floating,
            content: Text('${product.productName} added to cart'),
          ),
        );
      } else {
        setState(() {
          _isProcessingAction = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to add usual item to cart')),
        );
      }
    } catch (e) {
      debugPrint('Error adding usual to cart: $e');
      setState(() {
        _isProcessingAction = false;
      });
    }
  }

  void _showUsualVariantPicker(usuals.Product product) {
    if (product.variants.isEmpty) return;

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Container(
          padding: const EdgeInsets.symmetric(vertical: 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Select Variant',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF374338),
                  fontFamily: 'ITC Avant Garde Gothic Pro',
                ),
              ),
              const SizedBox(height: 10),
              ...product.variants.map((v) {
                final isSelected =
                    (_selectedUsualVariants[product.id]?.id ?? product.variants.first.id) ==
                        v.id;
                return ListTile(
                  title: Text(v.varientSize),
                  trailing: Text('\$${v.productPrice}'),
                  selected: isSelected,
                  selectedTileColor: AppTheme.instance.backgroundColor,
                  onTap: () {
                    setState(() {
                      _selectedUsualVariants[product.id] = v;
                    });
                    Navigator.pop(context);
                  },
                );
              }),
              const SizedBox(height: 50),
            ],
          ),
        );
      },
    );
  }
}
