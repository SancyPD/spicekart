import 'package:flutter/material.dart';
import 'package:get/get.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF4D555C)),
          onPressed: () => Get.back(),
        ),
        title: const Text(
          'Privacy Policy',
          style: TextStyle(
            color: Color(0xFF4D555C),
            fontSize: 18,
            fontFamily: 'ITC Avant Garde Gothic Pro',
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Privacy Policy',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Color(0xFF4D555C),
                fontFamily: 'ITC Avant Garde Gothic Pro',
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'Last updated: March 27, 2026',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey,
                fontFamily: 'ITC Avant Garde Gothic Pro',
              ),
            ),
            const SizedBox(height: 20),
            _buildSection(
              title: '1. Information We Collect',
              content:
                  'We collect personal information that you provide to us, such as your name, email address, phone number, and delivery address. We also collect information about your device and how you interact with our app.',
            ),
            _buildSection(
              title: '2. How We Use Your Information',
              content:
                  'Your information is used to process your orders, manage your account, and provide you with a personalized shopping experience. We also use data to improve our services and communicate important updates to you.',
            ),
            _buildSection(
              title: '3. Data Sharing',
              content:
                  'We may share your information with trusted third-party service providers, such as delivery partners and payment processors (e.g., Stripe), solely to fulfill your requests and provide our services.',
            ),
            _buildSection(
              title: '4. Data Security',
              content:
                  'We implement various security measures to protect your personal information. However, no method of transmission over the internet or electronic storage is 100% secure, so we cannot guarantee absolute security.',
            ),
            _buildSection(
              title: '5. Your Rights',
              content:
                  'You have the right to access, update, or delete your personal information at any time. You can manage most of your data directly through the "My Account" section of the app.',
            ),
            _buildSection(
              title: '6. Cookies & Tracking',
              content:
                  'We use technologies like local storage to enhance your experience, remember your preferences, and analyze app traffic. You can manage these settings through your device settings.',
            ),
            _buildSection(
              title: '7. Third-Party Links',
              content:
                  'Our app may contain links to other websites or services. We are not responsible for the privacy practices or content of these third-party sites.',
            ),
            _buildSection(
              title: '8. Changes to This Policy',
              content:
                  'We may update our Privacy Policy from time to time. Any changes will be posted on this page with an updated "Last updated" date. We encourage you to review this policy periodically.',
            ),
            _buildSection(
              title: '9. Contact Us',
              content:
                  'If you have any questions or concerns regarding our Privacy Policy, please reach out to us through the support section or help center in the app.',
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildSection({required String title, required String content}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 20),
        Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Color(0xFF4D555C),
            fontFamily: 'ITC Avant Garde Gothic Pro',
          ),
        ),
        const SizedBox(height: 10),
        Text(
          content,
          style: const TextStyle(
            fontSize: 16,
            color: Color(0xFF4D555C),
            fontFamily: 'ITC Avant Garde Gothic Pro',
            height: 1.5,
          ),
        ),
      ],
    );
  }
}
