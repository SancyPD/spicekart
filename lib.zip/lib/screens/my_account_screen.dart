import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../utils/app_theme.dart';
import '../services/api_service.dart';
import 'login_screen.dart';
import 'wishlist_screen.dart';
import 'order_history_screen.dart';
import 'package:get/get.dart';
import 'subscription_screen.dart';
import 'active_subscription_screen.dart';
import 'personal_info_screen.dart';
import 'terms_conditions_screen.dart';
import 'privacy_policy_screen.dart';

class MyAccountScreen extends StatefulWidget {
  const MyAccountScreen({super.key});

  @override
  State<MyAccountScreen> createState() => _MyAccountScreenState();
}

class _MyAccountScreenState extends State<MyAccountScreen> {
  bool _isLoggedIn = false; // Change to true when user logs in

  @override
  void initState() {
    super.initState();
    _isLoggedIn = ApiService.accessToken != null;
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.white,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.light,
      ),
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Column(
            children: [
            // Header Section
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              color: Colors.white,
                child: GestureDetector(
                  onTap: () => Navigator.pop(context),
                  behavior: HitTestBehavior.opaque,
                  child: const Padding(
                    padding: EdgeInsets.only(top: 8, bottom: 8, right: 20),
                    child: Text(
                      'Back',
                      style: TextStyle(
                        color: Color(0xFF4D555C),
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
            ),
            // Content
            Expanded(
              child: Container(
                color: Colors.grey.shade100,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    if (!_isLoggedIn) _buildBeforeLoginCard(),
                    if (_isLoggedIn) ...[
                      _buildAfterLoginCard(),
                      const SizedBox(height: 16),
                    ],
                    if (!_isLoggedIn) const SizedBox(height: 16),
                    _buildMenuCard(),
                    if (_isLoggedIn) ...[
                      const SizedBox(height: 10),
                      _buildLogOutButton(),
                    ],
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
          Container(color: Colors.grey.shade100, height: 16),
            // Footer at bottom
            Container(
              color: Colors.grey.shade100,
              child: Column(
                children: [
                  _buildFooter(),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

  Widget _buildBeforeLoginCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          // Profile Icon
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const LoginScreen()),
              );
            },
            child: Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: AppTheme.instance.mutedColor,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 2),
              ),
              child: const Icon(
                Icons.person_outline,
                color: Colors.white,
                size: 40,
              ),
            ),
          ),
          const SizedBox(height: 16),
          // Login / Sign up Text
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const LoginScreen()),
              );
            },
            child: const Text(
              'Login / Sign up',
              style: TextStyle(
                color: Color(0xFF4D555C),
                fontSize: 18,
                fontFamily: 'ITC Avant Garde Gothic Pro',
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          const SizedBox(height: 8),
          // Sign up Text
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const LoginScreen()),
              );
            },
            child: const Text(
              'Don\'t have an Account? Sign up',
              style: TextStyle(
                color: Color(0xFF7F858A),
                fontSize: 14,
                fontFamily: 'ITC Avant Garde Gothic Pro',
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAfterLoginCard() {
    return Row(
      children: [
        Expanded(
          child: _buildActionCard(
            icon: Icons.description_outlined,
            title: 'Order history',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const OrderHistoryScreen()),
              );
            },
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _buildActionCard(
            icon: Icons.favorite_outline,
            title: 'My Wishlist',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const WishlistScreen()),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildActionCard({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: AppTheme.instance.mutedColor,
                shape: BoxShape.circle,
              ),
              child: Icon(
                icon,
                color: Colors.white,
                size: 25,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: const TextStyle(
                color: Color(0xFF4D555C),
                fontSize: 12,
                fontFamily: 'ITC Avant Garde Gothic Pro',
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuCard() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: _isLoggedIn
            ? [
                _buildMenuItemWithIcon(
                  icon: Icons.account_balance_wallet_outlined,
                  title: 'Account',
                  onTap: () {
                    // Navigate to Account
                  },
                ),
                _buildMenuItemWithIcon(
                  icon: Icons.payment_outlined,
                  title: 'Payment',
                  onTap: () {
                    // Navigate to Payment
                  },
                ),
                /*
                _buildMenuItemWithIcon(
                  icon: Icons.subscriptions_outlined,
                  title: 'Subscription',
                  onTap: () async {
                    // Show loading dialog
                    Get.dialog(
                      const Center(child: CircularProgressIndicator()),
                      barrierDismissible: false,
                    );

                    // Call API
                    final response = await ApiService.checkActiveSubscription();

                    // Hide loading dialog
                    if (Get.isDialogOpen ?? false) {
                      Get.back();
                    }

                    if (response['data'] == null) {
                      // No active subscription, show plans
                      Get.to(() => const SubscriptionScreen(isFromMyAccount: true));
                    } else {
                      // Active subscription found, show details screen
                      Get.to(() => ActiveSubscriptionScreen(
                        subscriptionData: response['data'],
                      ));
                    }
                  },
                ),
                */
                _buildMenuItemWithIcon(
                  icon: Icons.person_outline,
                  title: 'Personal info',
                  onTap: () {
                    Get.to(() => const PersonalInfoScreen());
                  },
                ),
                _buildMenuItemWithIcon(
                  icon: Icons.sync_outlined,
                  title: 'Preferences',
                  onTap: () {
                    // Navigate to Preferences
                  },
                ),
                _buildMenuItemWithIcon(
                  icon: Icons.settings_outlined,
                  title: 'Settings',
                  onTap: () {
                    // Navigate to Settings
                  },
                ),
                _buildMenuItem(
                  assetPath: 'assets/images/terms.png',
                  title: 'Terms & Conditions',
                  onTap: () {
                    Get.to(() => const TermsConditionsScreen());
                  },
                ),
                _buildMenuItem(
                  assetPath: 'assets/images/privacy.png',
                  title: 'Privacy policy',
                  onTap: () {
                    Get.to(() => const PrivacyPolicyScreen());
                  },
                ),
              ]
            : [
                _buildMenuItem(
                  assetPath: 'assets/images/faqs.png',
                  title: 'FAQs',
                  onTap: () {
                    // Navigate to FAQs
                  },
                ),
                _buildMenuItem(
                  assetPath: 'assets/images/terms.png',
                  title: 'Terms & Conditions',
                  onTap: () {
                    Get.to(() => const TermsConditionsScreen());
                  },
                ),
                _buildMenuItem(
                  assetPath: 'assets/images/privacy.png',
                  title: 'Privacy policy',
                  onTap: () {
                    Get.to(() => const PrivacyPolicyScreen());
                  },
                ),
              ],
      ),
    );
  }

  Widget _buildMenuItem({
    required String assetPath,
    required String title,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        child: Row(
          children: [
            Image.asset(
              assetPath,
              width: 24,
              height: 24,
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  color: Color(0xFF4D555C),
                  fontSize: 14,
                  fontFamily: 'ITC Avant Garde Gothic Pro',
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            const Icon(Icons.chevron_right, color: Color(0x4D555CD5)),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuItemWithIcon({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        child: Row(
          children: [
            Icon(icon, color: const Color(0xFF4D555C), size: 24),
            const SizedBox(width: 16),
            Expanded(
              child: Text(
                title,
                style: TextStyle(
                  color: const Color(0xFF4D555C),
                  fontSize: 14,
                  fontFamily: 'ITC Avant Garde Gothic Pro',
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            const Icon(Icons.chevron_right, color: Color(0x4D555CD5)),
          ],
        ),
      ),
    );
  }

  Future<void> _showLogoutDialog() async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Logout'),
          content: const Text('Are you sure to Logout?'),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: const Text('Okay'),
              onPressed: () async {
                Navigator.of(context).pop();
                await _handleLogout();
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _handleLogout() async {
    // Optional: Show loading indicator here if the API takes time
    await ApiService.logout();
    if (mounted) {
      setState(() {
        _isLoggedIn = false;
      });
      Get.offAll(() => const LoginScreen());
    }
  }

  Widget _buildLogOutButton() {
    return InkWell(
      onTap: _showLogoutDialog,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Log Out',
              style: TextStyle(
                color: AppTheme.instance.mutedColor,
                fontSize: 16,
                fontFamily: 'ITC Avant Garde Gothic Pro',
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(width: 8),
            Icon(
              Icons.arrow_forward,
              color: AppTheme.instance.mutedColor,
              size: 20,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFooter() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        // Logo with Chili Pepper
        Center(
          child: Image.asset(
            'assets/images/logo_horizontal.png',
            fit: BoxFit.contain,
            height: _isLoggedIn ? 45: 68,
          ),
        ),
        const SizedBox(height: 8),
        // Version
        Center(
          child: const Text(
            'Version 1.0',
            style: TextStyle(
              color:  Color(0xFF4D555C),
              fontSize: 14,
              fontFamily: 'ITC Avant Garde Gothic Pro',
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ],
    );
  }
}
