import 'package:flutter/material.dart';
import 'package:get/get.dart';

class TermsConditionsScreen extends StatelessWidget {
  const TermsConditionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF4D555C)),
          onPressed: () => Get.back(),
        ),
        title: const Text(
          'Terms & Conditions',
          style: TextStyle(
            color: Color(0xFF4D555C),
            fontSize: 18,
            fontFamily: 'ITC Avant Garde Gothic Pro',
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Terms & Conditions',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Color(0xFF4D555C),
                fontFamily: 'ITC Avant Garde Gothic Pro',
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'Last updated: March 27, 2026',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey,
                fontFamily: 'ITC Avant Garde Gothic Pro',
              ),
            ),
            const SizedBox(height: 20),
            _buildSection(
              title: '1. Introduction',
              content:
                  'Welcome to SpiceKart. By accessing or using our mobile application, you agree to comply with and be bound by these Terms & Conditions. These terms govern your relationship with SpiceKart in relation to our service.',
            ),
            _buildSection(
              title: '2. Eligibility',
              content:
                  'To use SpiceKart, you must be at least 18 years of age. By creating an account, you represent and warrant that you meet this requirement and that all information provided is accurate and complete.',
            ),
            _buildSection(
              title: '3. Account Security',
              content:
                  'You are responsible for maintaining the confidentiality of your account credentials. You agree to notify us immediately of any unauthorized use of your account or any other breach of security.',
            ),
            _buildSection(
              title: '4. Ordering & Delivery',
              content:
                  'SpiceKart provides an online marketplace for grocery products. Delivery slots are subject to availability. While we strive to deliver within the selected timeframe, delays may occur due to unforeseen circumstances.',
            ),
            _buildSection(
              title: '5. Pricing & Payments',
              content:
                  'Prices for products are listed in the app and are subject to change. Fees such as delivery charges and taxes will be added during checkout. Payments can be made via Stripe (credit/debit cards) or Cash on Delivery (COD).',
            ),
            _buildSection(
              title: '6. Cancellations & Refunds',
              content:
                  'Orders can only be cancelled before they are prepared for delivery. Refunds for damaged or missing items will be processed according to our internal policies after verification.',
            ),
            _buildSection(
              title: '7. Limitation of Liability',
              content:
                  'SpiceKart shall not be liable for any indirect, incidental, special, consequential, or punitive damages arising out of your use of the service or any products purchased through the app.',
            ),
            _buildSection(
              title: '8. Governing Law',
              content:
                  'These Terms & Conditions shall be governed by and construed in accordance with the laws of the jurisdiction in which SpiceKart operates.',
            ),
            _buildSection(
              title: '9. Changes to Terms',
              content:
                  'We reserve the right to modify these Terms & Conditions at any time. Changes will be effective immediately upon posting. Your continued use of the app signifies your acceptance of the updated terms.',
            ),
            _buildSection(
              title: '10. Contact Us',
              content:
                  'If you have any questions about these Terms & Conditions, please contact our support team through the help center in the app.',
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildSection({required String title, required String content}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 20),
        Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Color(0xFF4D555C),
            fontFamily: 'ITC Avant Garde Gothic Pro',
          ),
        ),
        const SizedBox(height: 10),
        Text(
          content,
          style: const TextStyle(
            fontSize: 16,
            color: Color(0xFF4D555C),
            fontFamily: 'ITC Avant Garde Gothic Pro',
            height: 1.5,
          ),
        ),
      ],
    );
  }
}
