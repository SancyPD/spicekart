import 'dart:convert';
import 'package:spicekart/utils/string_extensions.dart';

OrderHistoryResponse orderHistoryResponseFromJson(String str) => OrderHistoryResponse.fromJson(json.decode(str));

String orderHistoryResponseToJson(OrderHistoryResponse data) => json.encode(data.toJson());

class OrderHistoryResponse {
  int status;
  String message;
  Data data;

  OrderHistoryResponse({
    required this.status,
    required this.message,
    required this.data,
  });

  factory OrderHistoryResponse.fromJson(Map<String, dynamic> json) => OrderHistoryResponse(
    status: json["status"] ?? 0,
    message: json["message"] ?? "",
    data: Data.fromJson(json["data"] ?? {}),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "data": data.toJson(),
  };
}

class Data {
  int currentPage;
  List<Datum> data;
  String firstPageUrl;
  int from;
  int lastPage;
  String lastPageUrl;
  List<Link> links;
  String nextPageUrl;
  String path;
  int perPage;
  dynamic prevPageUrl;
  int to;
  int total;

  Data({
    required this.currentPage,
    required this.data,
    required this.firstPageUrl,
    required this.from,
    required this.lastPage,
    required this.lastPageUrl,
    required this.links,
    required this.nextPageUrl,
    required this.path,
    required this.perPage,
    required this.prevPageUrl,
    required this.to,
    required this.total,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    currentPage: json["current_page"] ?? 0,
    data: json["data"] != null ? List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))) : [],
    firstPageUrl: json["first_page_url"] ?? "",
    from: json["from"] ?? 0,
    lastPage: json["last_page"] ?? 0,
    lastPageUrl: json["last_page_url"] ?? "",
    links: json["links"] != null ? List<Link>.from(json["links"].map((x) => Link.fromJson(x))) : [],
    nextPageUrl: json["next_page_url"] ?? "",
    path: json["path"] ?? "",
    perPage: json["per_page"] ?? 0,
    prevPageUrl: json["prev_page_url"],
    to: json["to"] ?? 0,
    total: json["total"] ?? 0,
  );

  Map<String, dynamic> toJson() => {
    "current_page": currentPage,
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
    "first_page_url": firstPageUrl,
    "from": from,
    "last_page": lastPage,
    "last_page_url": lastPageUrl,
    "links": List<dynamic>.from(links.map((x) => x.toJson())),
    "next_page_url": nextPageUrl,
    "path": path,
    "per_page": perPage,
    "prev_page_url": prevPageUrl,
    "to": to,
    "total": total,
  };
}

class Datum {
  int id;
  String orderNumber;
  String subTotal;
  String taxAmount;
  String deliveryFee;
  String tipAmount;
  String couponDiscount;
  String walletUsed;
  String totalAmount;
  String paymentMethod;
  String paymentStatus;
  String orderStatus;
  DateTime placedAt;
  dynamic deliveryVerificationCode;
  dynamic deliveryVerifiedAt;
  Address address;
  DeliverySlot deliverySlot;
  List<Item> items;

  Datum({
    required this.id,
    required this.orderNumber,
    required this.subTotal,
    required this.taxAmount,
    required this.deliveryFee,
    required this.tipAmount,
    required this.couponDiscount,
    required this.walletUsed,
    required this.totalAmount,
    required this.paymentMethod,
    required this.paymentStatus,
    required this.orderStatus,
    required this.placedAt,
    required this.deliveryVerificationCode,
    required this.deliveryVerifiedAt,
    required this.address,
    required this.deliverySlot,
    required this.items,
  });

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["id"] ?? 0,
    orderNumber: json["order_number"] ?? "",
    subTotal: json["sub_total"] ?? "0.00",
    taxAmount: json["tax_amount"] ?? "0.00",
    deliveryFee: json["delivery_fee"] ?? "0.00",
    tipAmount: json["tip_amount"] ?? "0.00",
    couponDiscount: json["coupon_discount"] ?? "0.00",
    walletUsed: json["wallet_used"] ?? "0.00",
    totalAmount: json["total_amount"] ?? "0.00",
    paymentMethod: json["payment_method"] ?? "",
    paymentStatus: json["payment_status"] ?? "",
    orderStatus: json["order_status"] ?? "",
    placedAt: json["placed_at"] != null ? DateTime.parse(json["placed_at"]) : DateTime.now(),
    deliveryVerificationCode: json["delivery_verification_code"],
    deliveryVerifiedAt: json["delivery_verified_at"],
    address: Address.fromJson(json["address"] ?? {}),
    deliverySlot: DeliverySlot.fromJson(json["delivery_slot"] ?? {}),
    items: json["items"] != null ? List<Item>.from(json["items"].map((x) => Item.fromJson(x))) : [],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "order_number": orderNumber,
    "sub_total": subTotal,
    "tax_amount": taxAmount,
    "delivery_fee": deliveryFee,
    "tip_amount": tipAmount,
    "coupon_discount": couponDiscount,
    "wallet_used": walletUsed,
    "total_amount": totalAmount,
    "payment_method": paymentMethod,
    "payment_status": paymentStatus,
    "order_status": orderStatus,
    "placed_at": placedAt.toIso8601String(),
    "delivery_verification_code": deliveryVerificationCode,
    "delivery_verified_at": deliveryVerifiedAt,
    "address": address.toJson(),
    "delivery_slot": deliverySlot.toJson(),
    "items": List<dynamic>.from(items.map((x) => x.toJson())),
  };
}

class Address {
  String firstName;
  String lastName;
  String addressLine1;
  dynamic addressLine2;
  String landmark;
  String city;
  String state;
  String postalCode;
  String country;

  Address({
    required this.firstName,
    required this.lastName,
    required this.addressLine1,
    required this.addressLine2,
    required this.landmark,
    required this.city,
    required this.state,
    required this.postalCode,
    required this.country,
  });

  factory Address.fromJson(Map<String, dynamic> json) => Address(
    firstName: json["first_name"] ?? "",
    lastName: json["last_name"] ?? "",
    addressLine1: json["address_line1"] ?? "",
    addressLine2: json["address_line2"],
    landmark: json["landmark"] ?? "",
    city: json["city"] ?? "",
    state: json["state"] ?? "",
    postalCode: json["postal_code"] ?? "",
    country: json["country"] ?? "",
  );

  Map<String, dynamic> toJson() => {
    "first_name": firstName,
    "last_name": lastName,
    "address_line1": addressLine1,
    "address_line2": addressLine2,
    "landmark": landmark,
    "city": city,
    "state":state,
    "postal_code": postalCode,
    "country": country,
  };
}


class DeliverySlot {
  int id;
  dynamic name;
  String startTime;
  String endTime;
  DateTime date;

  DeliverySlot({
    required this.id,
    required this.name,
    required this.startTime,
    required this.endTime,
    required this.date,
  });

  factory DeliverySlot.fromJson(Map<String, dynamic> json) => DeliverySlot(
    id: json["id"] ?? 0,
    name: json["name"],
    startTime: json["start_time"] ?? "",
    endTime: json["end_time"] ?? "",
    date: json["date"] != null ? DateTime.parse(json["date"]) : DateTime.now(),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "start_time": startTime,
    "end_time": endTime,
    "date": "${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}",
  };
}

class Item {
  int id;
  String productName;
  String unitPrice;
  int quantity;
  String totalPrice;
  Product product;
  Variant variant;

  Item({
    required this.id,
    required this.productName,
    required this.unitPrice,
    required this.quantity,
    required this.totalPrice,
    required this.product,
    required this.variant,
  });

  factory Item.fromJson(Map<String, dynamic> json) => Item(
    id: json["id"] ?? 0,
    productName: (json["product_name"] as String? ?? "").toSentenceCase(),
    unitPrice: json["unit_price"] ?? "0.00",
    quantity: json["quantity"] ?? 0,
    totalPrice: json["total_price"] ?? "0.00",
    product: Product.fromJson(json["product"] ?? {}),
    variant: Variant.fromJson(json["variant"] ?? {}),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "product_name": productName,
    "unit_price": unitPrice,
    "quantity": quantity,
    "total_price": totalPrice,
    "product": product.toJson(),
    "variant": variant.toJson(),
  };
}

class Product {
  int id;
  String slug;
  String productName;
  String productDescription;
  String productBarcode;
  int averageRating;
  int totalRatings;
  int categoryId;
  int brandId;
  String productImage;
  dynamic metaTitle;
  dynamic metaDescription;
  dynamic metaKeywords;
  String productTax;
  String productStatus;
  bool isFavourite;

  Product({
    required this.id,
    required this.slug,
    required this.productName,
    required this.productDescription,
    required this.productBarcode,
    required this.averageRating,
    required this.totalRatings,
    required this.categoryId,
    required this.brandId,
    required this.productImage,
    required this.metaTitle,
    required this.metaDescription,
    required this.metaKeywords,
    required this.productTax,
    required this.productStatus,
    required this.isFavourite,
  });

  factory Product.fromJson(Map<String, dynamic> json) => Product(
    id: json["id"] ?? 0,
    slug: json["slug"] ?? "",
    productName: (json["product_name"] as String? ?? "").toSentenceCase(),
    productDescription: json["product_description"] ?? "",
    productBarcode: json["product_barcode"] ?? "",
    averageRating: json["average_rating"] ?? 0,
    totalRatings: json["total_ratings"] ?? 0,
    categoryId: json["category_id"] ?? 0,
    brandId: json["brand_id"] ?? 0,
    productImage: json["product_image"] ?? "",
    metaTitle: json["meta_title"],
    metaDescription: json["meta_description"],
    metaKeywords: json["meta_keywords"],
    productTax: json["product_tax"] ?? "0.00",
    productStatus: json["product_status"] ?? "",
    isFavourite: json["is_favourite"] ?? false,
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "slug": slug,
    "product_name": productName,
    "product_description": productDescription,
    "product_barcode": productBarcode,
    "average_rating": averageRating,
    "total_ratings": totalRatings,
    "category_id": categoryId,
    "brand_id": brandId,
    "product_image": productImage,
    "meta_title": metaTitle,
    "meta_description": metaDescription,
    "meta_keywords": metaKeywords,
    "product_tax": productTax,
    "product_status": productStatus,
    "is_favourite": isFavourite,
  };
}




class Variant {
  int id;
  int productId;
  String varientSize;
  String productPrice;
  dynamic storePrice;

  Variant({
    required this.id,
    required this.productId,
    required this.varientSize,
    required this.productPrice,
    required this.storePrice,
  });

  factory Variant.fromJson(Map<String, dynamic> json) => Variant(
    id: json["id"] ?? 0,
    productId: json["product_id"] ?? 0,
    varientSize: json["varient_size"] ?? "",
    productPrice: json["product_price"] ?? "0.00",
    storePrice: json["store_price"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "product_id": productId,
    "varient_size": varientSize,
    "product_price": productPrice,
    "store_price": storePrice,
  };
}

class Link {
  String url;
  String label;
  int page;
  bool active;

  Link({
    required this.url,
    required this.label,
    required this.page,
    required this.active,
  });

  factory Link.fromJson(Map<String, dynamic> json) => Link(
    url: json["url"] ?? "",
    label: json["label"] ?? "",
    page: json["page"] ?? 0,
    active: json["active"] ?? false,
  );

  Map<String, dynamic> toJson() => {
    "url": url,
    "label": label,
    "page": page,
    "active": active,
  };
}

class EnumValues<T> {
  Map<String, T> map;
  late Map<T, String> reverseMap;

  EnumValues(this.map);

  Map<T, String> get reverse {
    reverseMap = map.map((k, v) => MapEntry(v, k));
    return reverseMap;
  }
}