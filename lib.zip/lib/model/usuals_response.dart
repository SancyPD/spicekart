import 'dart:convert';
import 'package:spicekart/utils/string_extensions.dart';

UsualsResponse usualsResponseFromJson(String str) => UsualsResponse.fromJson(json.decode(str));

String usualsResponseToJson(UsualsResponse data) => json.encode(data.toJson());

class UsualsResponse {
  int status;
  String message;
  List<Datum> data;
  Meta? meta;

  UsualsResponse({
    required this.status,
    required this.message,
    required this.data,
    this.meta,
  });

  factory UsualsResponse.fromJson(Map<String, dynamic> json) => UsualsResponse(
    status: json["status"],
    message: json["message"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
    meta: json["meta"] != null ? Meta.fromJson(json["meta"]) : null,
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
    "meta": meta?.toJson(),
  };
}

class Meta {
  int currentPage;
  int perPage;
  int total;
  int lastPage;

  Meta({
    required this.currentPage,
    required this.perPage,
    required this.total,
    required this.lastPage,
  });

  factory Meta.fromJson(Map<String, dynamic> json) => Meta(
    currentPage: json["current_page"] ?? 1,
    perPage: json["per_page"] ?? 20,
    total: json["total"] ?? 0,
    lastPage: json["last_page"] ?? 1,
  );

  Map<String, dynamic> toJson() => {
    "current_page": currentPage,
    "per_page": perPage,
    "total": total,
    "last_page": lastPage,
  };
}

class Datum {
  int productId;
  int totalQuantity;
  int lineCount;
  Product product;

  Datum({
    required this.productId,
    required this.totalQuantity,
    required this.lineCount,
    required this.product,
  });

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    productId: json["product_id"],
    totalQuantity: json["total_quantity"],
    lineCount: json["line_count"],
    product: Product.fromJson(json["product"]),
  );

  Map<String, dynamic> toJson() => {
    "product_id": productId,
    "total_quantity": totalQuantity,
    "line_count": lineCount,
    "product": product.toJson(),
  };
}

class Product {
  int id;
  String slug;
  String productName;
  String productDescription;
  String productBarcode;
  int averageRating;
  int totalRatings;
  int categoryId;
  int brandId;
  String productImage;
  dynamic metaTitle;
  dynamic metaDescription;
  dynamic metaKeywords;
  String productTax;
  String productStatus;
  List<Variant> variants;
  List<Region> regions;
  List<Rating> ratings;
  List<Image> images;
  bool isFavourite;

  Product({
    required this.id,
    required this.slug,
    required this.productName,
    required this.productDescription,
    required this.productBarcode,
    required this.averageRating,
    required this.totalRatings,
    required this.categoryId,
    required this.brandId,
    required this.productImage,
    required this.metaTitle,
    required this.metaDescription,
    required this.metaKeywords,
    required this.productTax,
    required this.productStatus,
    required this.variants,
    required this.regions,
    required this.ratings,
    required this.images,
    required this.isFavourite,
  });

  factory Product.fromJson(Map<String, dynamic> json) => Product(
    id: json["id"],
    slug: json["slug"],
    productName: (json["product_name"] as String? ?? "").toSentenceCase(),
    productDescription: json["product_description"],
    productBarcode: json["product_barcode"],
    averageRating: json["average_rating"],
    totalRatings: json["total_ratings"],
    categoryId: json["category_id"],
    brandId: json["brand_id"],
    productImage: json["product_image"],
    metaTitle: json["meta_title"],
    metaDescription: json["meta_description"],
    metaKeywords: json["meta_keywords"],
    productTax: json["product_tax"],
    productStatus: json["product_status"],
    variants: List<Variant>.from(json["variants"].map((x) => Variant.fromJson(x))),
    regions: List<Region>.from(json["regions"].map((x) => Region.fromJson(x))),
    ratings: List<Rating>.from(json["ratings"].map((x) => Rating.fromJson(x))),
    images: List<Image>.from(json["images"].map((x) => Image.fromJson(x))),
    isFavourite: json["is_favourite"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "slug": slug,
    "product_name": productName,
    "product_description": productDescription,
    "product_barcode": productBarcode,
    "average_rating": averageRating,
    "total_ratings": totalRatings,
    "category_id": categoryId,
    "brand_id": brandId,
    "product_image": productImage,
    "meta_title": metaTitle,
    "meta_description": metaDescription,
    "meta_keywords": metaKeywords,
    "product_tax": productTax,
    "product_status": productStatus,
    "variants": List<dynamic>.from(variants.map((x) => x.toJson())),
    "regions": List<dynamic>.from(regions.map((x) => x.toJson())),
    "ratings": List<dynamic>.from(ratings.map((x) => x.toJson())),
    "images": List<dynamic>.from(images.map((x) => x.toJson())),
    "is_favourite": isFavourite,
  };
}

class Image {
  int id;
  String productImage;

  Image({
    required this.id,
    required this.productImage,
  });

  factory Image.fromJson(Map<String, dynamic> json) => Image(
    id: json["id"],
    productImage: json["product_image"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "product_image": productImage,
  };
}

class Rating {
  int ratingId;
  int rating;
  String reviewText;

  Rating({
    required this.ratingId,
    required this.rating,
    required this.reviewText,
  });

  factory Rating.fromJson(Map<String, dynamic> json) => Rating(
    ratingId: json["rating_id"],
    rating: json["rating"],
    reviewText: json["review_text"],
  );

  Map<String, dynamic> toJson() => {
    "rating_id": ratingId,
    "rating": rating,
    "review_text": reviewText,
  };
}

class Region {
  int id;
  int productId;
  int regionId;

  Region({
    required this.id,
    required this.productId,
    required this.regionId,
  });

  factory Region.fromJson(Map<String, dynamic> json) => Region(
    id: json["id"],
    productId: json["product_id"],
    regionId: json["region_id"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "product_id": productId,
    "region_id": regionId,
  };
}

class Variant {
  int id;
  int productId;
  String varientSize;
  String productPrice;
  dynamic storePrice;

  Variant({
    required this.id,
    required this.productId,
    required this.varientSize,
    required this.productPrice,
    required this.storePrice,
  });

  factory Variant.fromJson(Map<String, dynamic> json) => Variant(
    id: json["id"],
    productId: json["product_id"],
    varientSize: json["varient_size"],
    productPrice: json["product_price"],
    storePrice: json["store_price"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "product_id": productId,
    "varient_size": varientSize,
    "product_price": productPrice,
    "store_price": storePrice,
  };
}
