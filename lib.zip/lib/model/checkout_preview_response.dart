import 'dart:convert';
import 'package:spicekart/utils/string_extensions.dart';

import 'package:spicekart/model/delivery_slots.dart';

CheckoutPreviewResponse checkoutPreviewResponseFromJson(String str) => CheckoutPreviewResponse.fromJson(json.decode(str));

String checkoutPreviewResponseToJson(CheckoutPreviewResponse data) => json.encode(data.toJson());

class CheckoutPreviewResponse {
  int status;
  String message;
  Data data;

  CheckoutPreviewResponse({
    required this.status,
    required this.message,
    required this.data,
  });

  factory CheckoutPreviewResponse.fromJson(Map<String, dynamic> json) => CheckoutPreviewResponse(
    status: json["status"],
    message: json["message"],
    data: Data.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "data": data.toJson(),
  };
}

class Data {
  List<dynamic> issues;
  Cart? cart;
  DeliveryInstruction? deliveryInstruction;
  TotalAmountSummary? totalAmountSummary;

  Data({
    required this.issues,
    this.cart,
    this.deliveryInstruction,
    this.totalAmountSummary,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    issues: json["issues"] is List ? List<dynamic>.from(json["issues"].map((x) => x)) : [],
    cart: json["cart"] != null ? Cart.fromJson(json["cart"]) : null,
    deliveryInstruction: json["delivery_instruction"] != null ? DeliveryInstruction.fromJson(json["delivery_instruction"]) : null,
    totalAmountSummary: json["total_amount_summary"] != null ? TotalAmountSummary.fromJson(json["total_amount_summary"]) : null,
  );

  Map<String, dynamic> toJson() => {
    "issues": List<dynamic>.from(issues.map((x) => x)),
    "cart": cart?.toJson(),
    "delivery_instruction": deliveryInstruction?.toJson(),
    "total_amount_summary": totalAmountSummary?.toJson(),
  };
}

class Cart {
  int id;
  int userId;
  String? checkoutPhone;
  String? checkoutEmail;
  DateTime? checkoutPhoneVerifiedAt;
  dynamic coupon;
  String? discountAmount;
  Address? address;
  PropertyType? propertyType;
  Slot? deliverySlot;
  DateTime? deliveryDate;
  List<CartItem> cartItems;
  DateTime? createdAt;
  DateTime? updatedAt;

  Cart({
    required this.id,
    required this.userId,
    this.checkoutPhone,
    this.checkoutEmail,
    this.checkoutPhoneVerifiedAt,
    this.coupon,
    this.discountAmount,
    this.address,
    this.propertyType,
    this.deliverySlot,
    this.deliveryDate,
    required this.cartItems,
    this.createdAt,
    this.updatedAt,
  });

  factory Cart.fromJson(Map<String, dynamic> json) => Cart(
    id: json["id"],
    userId: json["user_id"],
    checkoutPhone: json["checkout_phone"]?.toString(),
    checkoutEmail: json["checkout_email"]?.toString(),
    checkoutPhoneVerifiedAt: json["checkout_phone_verified_at"] != null ? DateTime.parse(json["checkout_phone_verified_at"]) : null,
    coupon: json["coupon"],
    discountAmount: json["discount_amount"]?.toString(),
    address: json["address"] != null ? Address.fromJson(json["address"]) : null,
    propertyType: json["property_type"] != null ? PropertyType.fromJson(json["property_type"]) : null,
    deliverySlot: json["delivery_slot"] != null ? Slot.fromJson(json["delivery_slot"]) : null,
    deliveryDate: json["delivery_date"] != null ? DateTime.parse(json["delivery_date"]) : null,
    cartItems: json["cart_items"] is List 
        ? List<CartItem>.from(json["cart_items"].map((x) => CartItem.fromJson(x)))
        : [],
    createdAt: json["created_at"] != null ? DateTime.parse(json["created_at"]) : null,
    updatedAt: json["updated_at"] != null ? DateTime.parse(json["updated_at"]) : null,
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "user_id": userId,
    "checkout_phone": checkoutPhone,
    "checkout_email": checkoutEmail,
    "checkout_phone_verified_at": checkoutPhoneVerifiedAt?.toIso8601String(),
    "coupon": coupon,
    "discount_amount": discountAmount,
    "address": address?.toJson(),
    "property_type": propertyType?.toJson(),
    "delivery_slot": deliverySlot?.toJson(),
    "delivery_date": deliveryDate != null ? "${deliveryDate!.year.toString().padLeft(4, '0')}-${deliveryDate!.month.toString().padLeft(2, '0')}-${deliveryDate!.day.toString().padLeft(2, '0')}" : null,
    "cart_items": List<dynamic>.from(cartItems.map((x) => x.toJson())),
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
  };
}

class Address {
  int userId;
  String firstName;
  String lastName;
  String addressLine1;
  dynamic addressLine2;
  String landmark;
  String city;
  String state;
  String postalCode;
  String country;
  String addressType;
  int isDefault;

  Address({
    required this.userId,
    required this.firstName,
    required this.lastName,
    required this.addressLine1,
    required this.addressLine2,
    required this.landmark,
    required this.city,
    required this.state,
    required this.postalCode,
    required this.country,
    required this.addressType,
    required this.isDefault,
  });

  factory Address.fromJson(Map<String, dynamic> json) => Address(
    userId: (json["user_id"] ?? 0) is int ? json["user_id"] : int.tryParse(json["user_id"].toString()) ?? 0,
    firstName: json["first_name"]?.toString() ?? "",
    lastName: json["last_name"]?.toString() ?? "",
    addressLine1: json["address_line1"]?.toString() ?? "",
    addressLine2: json["address_line2"],
    landmark: json["landmark"]?.toString() ?? "",
    city: json["city"]?.toString() ?? "",
    state: json["state"]?.toString() ?? "",
    postalCode: json["postal_code"]?.toString() ?? "",
    country: json["country"]?.toString() ?? "",
    addressType: json["address_type"]?.toString() ?? "",
    isDefault: (json["is_default"] ?? 0) is int ? json["is_default"] : int.tryParse(json["is_default"].toString()) ?? 0,
  );

  Map<String, dynamic> toJson() => {
    "user_id": userId,
    "first_name": firstName,
    "last_name": lastName,
    "address_line1": addressLine1,
    "address_line2": addressLine2,
    "landmark": landmark,
    "city": city,
    "state": state,
    "postal_code": postalCode,
    "country": country,
    "address_type": addressType,
    "is_default": isDefault,
  };
}

class CartItem {
  int id;
  int quantity;
  int isSavedForLater;
  Product product;
  Variant variant;

  CartItem({
    required this.id,
    required this.quantity,
    required this.isSavedForLater,
    required this.product,
    required this.variant,
  });

  factory CartItem.fromJson(Map<String, dynamic> json) => CartItem(
    id: (json["id"] ?? 0) is int ? json["id"] : int.tryParse(json["id"].toString()) ?? 0,
    quantity: (json["quantity"] ?? 1) is int ? json["quantity"] : int.tryParse(json["quantity"].toString()) ?? 1,
    isSavedForLater: (json["is_saved_for_later"] ?? 0) is int ? json["is_saved_for_later"] : int.tryParse(json["is_saved_for_later"].toString()) ?? 0,
    product: Product.fromJson(json["product"] ?? {}),
    variant: Variant.fromJson(json["variant"] ?? {}),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "quantity": quantity,
    "is_saved_for_later": isSavedForLater,
    "product": product.toJson(),
    "variant": variant.toJson(),
  };
}

class Product {
  int id;
  String slug;
  String productName;
  String productDescription;
  String productBarcode;
  int averageRating;
  int totalRatings;
  int categoryId;
  int brandId;
  String productImage;
  dynamic metaTitle;
  dynamic metaDescription;
  dynamic metaKeywords;
  String productTax;
  String productStatus;
  List<Region> regions;
  bool isFavourite;

  Product({
    required this.id,
    required this.slug,
    required this.productName,
    required this.productDescription,
    required this.productBarcode,
    required this.averageRating,
    required this.totalRatings,
    required this.categoryId,
    required this.brandId,
    required this.productImage,
    required this.metaTitle,
    required this.metaDescription,
    required this.metaKeywords,
    required this.productTax,
    required this.productStatus,
    required this.regions,
    required this.isFavourite,
  });

  factory Product.fromJson(Map<String, dynamic> json) => Product(
    id: (json["id"] ?? 0) is int ? json["id"] : int.tryParse(json["id"].toString()) ?? 0,
    slug: json["slug"]?.toString() ?? "",
    productName: (json["product_name"]?.toString() ?? "").toSentenceCase(),
    productDescription: json["product_description"]?.toString() ?? "",
    productBarcode: json["product_barcode"]?.toString() ?? "",
    averageRating: (json["average_rating"] ?? 0) is int ? json["average_rating"] : int.tryParse(json["average_rating"].toString()) ?? 0,
    totalRatings: (json["total_ratings"] ?? 0) is int ? json["total_ratings"] : int.tryParse(json["total_ratings"].toString()) ?? 0,
    categoryId: (json["category_id"] ?? 0) is int ? json["category_id"] : int.tryParse(json["category_id"].toString()) ?? 0,
    brandId: (json["brand_id"] ?? 0) is int ? json["brand_id"] : int.tryParse(json["brand_id"].toString()) ?? 0,
    productImage: json["product_image"]?.toString() ?? "",
    metaTitle: json["meta_title"],
    metaDescription: json["meta_description"],
    metaKeywords: json["meta_keywords"],
    productTax: json["product_tax"]?.toString() ?? "0",
    productStatus: json["product_status"]?.toString() ?? "0",
    regions: json["regions"] is List
        ? List<Region>.from(json["regions"].map((x) => Region.fromJson(x)))
        : [],
    isFavourite: json["is_favourite"] == true || json["is_favourite"] == 1,
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "slug": slug,
    "product_name": productName,
    "product_description": productDescription,
    "product_barcode": productBarcode,
    "average_rating": averageRating,
    "total_ratings": totalRatings,
    "category_id": categoryId,
    "brand_id": brandId,
    "product_image": productImage,
    "meta_title": metaTitle,
    "meta_description": metaDescription,
    "meta_keywords": metaKeywords,
    "product_tax": productTax,
    "product_status": productStatus,
    "regions": List<dynamic>.from(regions.map((x) => x.toJson())),
    "is_favourite": isFavourite,
  };
}

class Region {
  int id;
  int productId;
  int regionId;

  Region({
    required this.id,
    required this.productId,
    required this.regionId,
  });

  factory Region.fromJson(Map<String, dynamic> json) => Region(
    id: (json["id"] ?? 0) is int ? json["id"] : int.tryParse(json["id"].toString()) ?? 0,
    productId: (json["product_id"] ?? 0) is int ? json["product_id"] : int.tryParse(json["product_id"].toString()) ?? 0,
    regionId: (json["region_id"] ?? 0) is int ? json["region_id"] : int.tryParse(json["region_id"].toString()) ?? 0,
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "product_id": productId,
    "region_id": regionId,
  };
}

class Variant {
  int id;
  int productId;
  String varientSize;
  String productPrice;
  dynamic storePrice;

  Variant({
    required this.id,
    required this.productId,
    required this.varientSize,
    required this.productPrice,
    required this.storePrice,
  });

  factory Variant.fromJson(Map<String, dynamic> json) => Variant(
    id: (json["id"] ?? 0) is int ? json["id"] : int.tryParse(json["id"].toString()) ?? 0,
    productId: (json["product_id"] ?? 0) is int ? json["product_id"] : int.tryParse(json["product_id"].toString()) ?? 0,
    varientSize: json["varient_size"]?.toString() ?? "",
    productPrice: json["product_price"]?.toString() ?? "0",
    storePrice: json["store_price"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "product_id": productId,
    "varient_size": varientSize,
    "product_price": productPrice,
    "store_price": storePrice,
  };
}



class PropertyType {
  int id;
  String name;

  PropertyType({
    required this.id,
    required this.name,
  });

  factory PropertyType.fromJson(Map<String, dynamic> json) => PropertyType(
    id: (json["id"] ?? 0) is int ? json["id"] : int.tryParse(json["id"].toString()) ?? 0,
    name: json["name"]?.toString() ?? "",
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
  };
}

class DeliveryInstruction {
  int propertyTypeId;
  String gateCode;
  String deliveryNotes;
  String dropOffLocation;
  String source;

  DeliveryInstruction({
    required this.propertyTypeId,
    required this.gateCode,
    required this.deliveryNotes,
    required this.dropOffLocation,
    required this.source,
  });

  factory DeliveryInstruction.fromJson(Map<String, dynamic> json) => DeliveryInstruction(
    propertyTypeId: json["property_type_id"] ?? 0,
    gateCode: json["gate_code"]?.toString() ?? "",
    deliveryNotes: json["delivery_notes"]?.toString() ?? "",
    dropOffLocation: json["drop_off_location"]?.toString() ?? "",
    source: json["source"]?.toString() ?? "",
  );

  Map<String, dynamic> toJson() => {
    "property_type_id": propertyTypeId,
    "gate_code": gateCode,
    "delivery_notes": deliveryNotes,
    "drop_off_location": dropOffLocation,
    "source": source,
  };
}

class TotalAmountSummary {
  double subtotal;
  double discount;
  double deliveryFee;
  double tax;
  double walletBalance;
  double walletUsed;
  int tipPercent;
  double tipAmount;
  double cashback;
  double total;

  TotalAmountSummary({
    required this.subtotal,
    required this.discount,
    required this.deliveryFee,
    required this.tax,
    required this.walletBalance,
    required this.walletUsed,
    required this.tipPercent,
    required this.tipAmount,
    required this.cashback,
    required this.total,
  });

  factory TotalAmountSummary.fromJson(Map<String, dynamic> json) => TotalAmountSummary(
    subtotal: (json["subtotal"] ?? 0).toDouble(),
    discount: (json["discount"] ?? 0).toDouble(),
    deliveryFee: (json["delivery_fee"] ?? 0).toDouble(),
    tax: (json["tax"] ?? 0).toDouble(),
    walletBalance: (json["wallet_balance"] ?? 0).toDouble(),
    walletUsed: (json["wallet_used"] ?? 0).toDouble(),
    tipPercent: json["tip_percent"] ?? 0,
    tipAmount: (json["tip_amount"] ?? 0).toDouble(),
    cashback: (json["cashback"] ?? 0).toDouble(),
    total: (json["total"] ?? 0).toDouble(),
  );

  Map<String, dynamic> toJson() => {
    "subtotal": subtotal,
    "discount": discount,
    "delivery_fee": deliveryFee,
    "tax": tax,
    "wallet_balance": walletBalance,
    "wallet_used": walletUsed,
    "tip_percent": tipPercent,
    "tip_amount": tipAmount,
    "cashback": cashback,
    "total": total,
  };
}
