import 'dart:convert';

CheckoutPreviewResponse checkoutPreviewResponseFromJson(String str) => CheckoutPreviewResponse.fromJson(json.decode(str));

String checkoutPreviewResponseToJson(CheckoutPreviewResponse data) => json.encode(data.toJson());

class CheckoutPreviewResponse {
  int status;
  String message;
  Data data;

  CheckoutPreviewResponse({
    required this.status,
    required this.message,
    required this.data,
  });

  factory CheckoutPreviewResponse.fromJson(Map<String, dynamic> json) => CheckoutPreviewResponse(
    status: json["status"],
    message: json["message"],
    data: Data.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "data": data.toJson(),
  };
}

class Data {
  Cart cart;
  TotalAmountSummary totalAmountSummary;

  Data({
    required this.cart,
    required this.totalAmountSummary,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    cart: Cart.fromJson(json["cart"]),
    totalAmountSummary: TotalAmountSummary.fromJson(json["total_amount_summary"]),
  );

  Map<String, dynamic> toJson() => {
    "cart": cart.toJson(),
    "total_amount_summary": totalAmountSummary.toJson(),
  };
}

class Cart {
  int id;
  int userId;
  dynamic coupon;
  String discountAmount;
  dynamic address;
  PropertyType propertyType;
  dynamic deliverySlot;
  dynamic deliveryDate;
  List<CartItem> cartItems;
  DateTime createdAt;
  DateTime updatedAt;

  Cart({
    required this.id,
    required this.userId,
    required this.coupon,
    required this.discountAmount,
    required this.address,
    required this.propertyType,
    required this.deliverySlot,
    required this.deliveryDate,
    required this.cartItems,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Cart.fromJson(Map<String, dynamic> json) => Cart(
    id: json["id"],
    userId: json["user_id"],
    coupon: json["coupon"],
    discountAmount: json["discount_amount"],
    address: json["address"],
    propertyType: PropertyType.fromJson(json["property_type"]),
    deliverySlot: json["delivery_slot"],
    deliveryDate: json["delivery_date"],
    cartItems: List<CartItem>.from(json["cart_items"].map((x) => CartItem.fromJson(x))),
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "user_id": userId,
    "coupon": coupon,
    "discount_amount": discountAmount,
    "address": address,
    "property_type": propertyType.toJson(),
    "delivery_slot": deliverySlot,
    "delivery_date": deliveryDate,
    "cart_items": List<dynamic>.from(cartItems.map((x) => x.toJson())),
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
  };
}

class CartItem {
  int id;
  int quantity;
  int isSavedForLater;
  Product product;
  Variant variant;

  CartItem({
    required this.id,
    required this.quantity,
    required this.isSavedForLater,
    required this.product,
    required this.variant,
  });

  factory CartItem.fromJson(Map<String, dynamic> json) => CartItem(
    id: json["id"],
    quantity: json["quantity"],
    isSavedForLater: json["is_saved_for_later"],
    product: Product.fromJson(json["product"]),
    variant: Variant.fromJson(json["variant"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "quantity": quantity,
    "is_saved_for_later": isSavedForLater,
    "product": product.toJson(),
    "variant": variant.toJson(),
  };
}

class Product {
  int id;
  String slug;
  String productName;
  String productDescription;
  String productBarcode;
  int averageRating;
  int totalRatings;
  int categoryId;
  int brandId;
  String productImage;
  dynamic metaTitle;
  dynamic metaDescription;
  dynamic metaKeywords;
  String productTax;
  String productStatus;
  List<Region> regions;
  bool isFavourite;

  Product({
    required this.id,
    required this.slug,
    required this.productName,
    required this.productDescription,
    required this.productBarcode,
    required this.averageRating,
    required this.totalRatings,
    required this.categoryId,
    required this.brandId,
    required this.productImage,
    required this.metaTitle,
    required this.metaDescription,
    required this.metaKeywords,
    required this.productTax,
    required this.productStatus,
    required this.regions,
    required this.isFavourite,
  });

  factory Product.fromJson(Map<String, dynamic> json) => Product(
    id: json["id"],
    slug: json["slug"],
    productName: json["product_name"],
    productDescription: json["product_description"],
    productBarcode: json["product_barcode"],
    averageRating: json["average_rating"],
    totalRatings: json["total_ratings"],
    categoryId: json["category_id"],
    brandId: json["brand_id"],
    productImage: json["product_image"],
    metaTitle: json["meta_title"],
    metaDescription: json["meta_description"],
    metaKeywords: json["meta_keywords"],
    productTax: json["product_tax"],
    productStatus: json["product_status"],
    regions: List<Region>.from(json["regions"].map((x) => Region.fromJson(x))),
    isFavourite: json["is_favourite"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "slug": slug,
    "product_name": productName,
    "product_description": productDescription,
    "product_barcode": productBarcode,
    "average_rating": averageRating,
    "total_ratings": totalRatings,
    "category_id": categoryId,
    "brand_id": brandId,
    "product_image": productImage,
    "meta_title": metaTitle,
    "meta_description": metaDescription,
    "meta_keywords": metaKeywords,
    "product_tax": productTax,
    "product_status": productStatus,
    "regions": List<dynamic>.from(regions.map((x) => x.toJson())),
    "is_favourite": isFavourite,
  };
}

class Region {
  int id;
  int productId;
  int regionId;

  Region({
    required this.id,
    required this.productId,
    required this.regionId,
  });

  factory Region.fromJson(Map<String, dynamic> json) => Region(
    id: json["id"],
    productId: json["product_id"],
    regionId: json["region_id"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "product_id": productId,
    "region_id": regionId,
  };
}

class Variant {
  int id;
  int productId;
  String varientSize;
  String productPrice;
  dynamic storePrice;

  Variant({
    required this.id,
    required this.productId,
    required this.varientSize,
    required this.productPrice,
    required this.storePrice,
  });

  factory Variant.fromJson(Map<String, dynamic> json) => Variant(
    id: json["id"],
    productId: json["product_id"],
    varientSize: json["varient_size"],
    productPrice: json["product_price"],
    storePrice: json["store_price"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "product_id": productId,
    "varient_size": varientSize,
    "product_price": productPrice,
    "store_price": storePrice,
  };
}

class PropertyType {
  int id;
  String name;

  PropertyType({
    required this.id,
    required this.name,
  });

  factory PropertyType.fromJson(Map<String, dynamic> json) => PropertyType(
    id: json["id"],
    name: json["name"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
  };
}

class TotalAmountSummary {
  int subtotal;
  int discount;
  int deliveryFee;
  double tax;
  int walletBalance;
  int walletUsed;
  int tipPercent;
  int tipAmount;
  double total;

  TotalAmountSummary({
    required this.subtotal,
    required this.discount,
    required this.deliveryFee,
    required this.tax,
    required this.walletBalance,
    required this.walletUsed,
    required this.tipPercent,
    required this.tipAmount,
    required this.total,
  });

  factory TotalAmountSummary.fromJson(Map<String, dynamic> json) => TotalAmountSummary(
    subtotal: json["subtotal"],
    discount: json["discount"],
    deliveryFee: json["delivery_fee"],
    tax: json["tax"].toDouble(),
    walletBalance: json["wallet_balance"],
    walletUsed: json["wallet_used"],
    tipPercent: json["tip_percent"],
    tipAmount: json["tip_amount"],
    total: json["total"].toDouble(),
  );

  Map<String, dynamic> toJson() => {
    "subtotal": subtotal,
    "discount": discount,
    "delivery_fee": deliveryFee,
    "tax": tax,
    "wallet_balance": walletBalance,
    "wallet_used": walletUsed,
    "tip_percent": tipPercent,
    "tip_amount": tipAmount,
    "total": total,
  };
}